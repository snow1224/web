function changeMsg(st){
    document.getElementById("ex1").innerHTML="The title is change~"+st;
}

function firstBt(){
    pArr = document.getElementsByTagName("p");
    
    pArr[2].innerHTML="Now change by firstBt...";
    pArr[2].style.backgroundColor="#333";
    pArr[2].style.color="white";
    pArr[2].style.display="block";
}

function SecondBt(){
    pArr = document.getElementsByTagName("p");
    
    pArr[3].innerHTML="Now change by SecondBt...";
    pArr[3].style.backgroundColor="blue";
    pArr[3].style.color="white";
}

function openMe(){
    x=document.getElementById("demo");
//    x.style.display="block";
    x.className="open";
}

function closeMe(){
    y=document.getElementById("demo");
//    y.style.display="none";
    y.className="close";
}